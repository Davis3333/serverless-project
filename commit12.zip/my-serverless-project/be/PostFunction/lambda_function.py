from aws_xray_sdk.core import xray_recorder
from aws_xray_sdk.core import patch_all
import json
import boto3

# Automatically instrument AWS SDK (boto3)
patch_all()


# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    trace_id = xray_recorder.current_segment().trace_id  # Get the trace ID
    logger.info(f"Trace ID: {trace_id}")  # Log the trace ID for reference

# Create a DynamoDB object using the AWS SDK
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('reacttable')

def lambda_handler(event, context):
    # Custom X-Ray segment for debugging
    with xray_recorder.in_segment('DynamoDBPutItem'):
        if 'D@vis@partitionkey' not in event or 'D@vis@sortkey' not in event:
            return {
                'statusCode': 400,
                'body': json.dumps("Error: Missing required keys 'D@vis@partitionkey' or 'D@vis@sortkey'")
            }

        # Extract values
        partition_key = event['D@vis@partitionkey']
        sort_key = event['D@vis@sortkey']
        student_id = event.get('studentid', '')
        name = event.get('name', '')
        student_class = event.get('class', '')
        age = event.get('age', 0)

        try:
            table.put_item(
                Item={
                    'D@vis@partitionkey': partition_key,
                    'D@vis@sortkey': sort_key,
                    'studentid': student_id,
                    'name': name,
                    'class': student_class,
                    'age': age
                }
            )
            return {
                'statusCode': 200,
                'body': json.dumps('Student data saved successfully!')
            }
        except Exception as e:
            return {
                'statusCode': 500,
                'body': json.dumps(f"Error: {str(e)}")
            }
