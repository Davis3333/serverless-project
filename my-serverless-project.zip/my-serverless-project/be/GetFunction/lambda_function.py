import json
import boto3
import logging
from aws_xray_sdk.core import xray_recorder, patch_all

# Patch libraries to automatically instrument supported AWS SDKs like boto3
patch_all()

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    trace_id = xray_recorder.current_segment().trace_id  # Get the trace ID
    logger.info(f"Trace ID: {trace_id}")  # Log the trace ID for reference


def lambda_handler(event, context):
    # Initialize a DynamoDB resource object for the specified region
    dynamodb = boto3.resource('dynamodb', region_name='ap-south-1')
    table = dynamodb.Table('reacttable')

    try:
        # Create a segment for the scan operation
        with xray_recorder.in_segment('DynamoDBScanSegment'):
            logger.info("Starting to scan the DynamoDB table.")

            # Initialize data container and scan parameters
            data = []
            response = table.scan(Limit=100)  # Add a limit to control the scan size
            data.extend(response['Items'])

            # If there are more items to scan, continue scanning in pages
            while 'LastEvaluatedKey' in response:
                response = table.scan(
                    ExclusiveStartKey=response['LastEvaluatedKey'],
                    Limit=100  # Maintain the limit to prevent excessive load
                )
                data.extend(response['Items'])

            logger.info(f"Retrieved {len(data)} items from the table.")
            xray_recorder.current_subsegment().put_annotation('ItemsRetrieved', len(data))

            return {
                "statusCode": 200,
                "body": json.dumps(data)
            }
    except Exception as e:
        logger.error(f"Error scanning DynamoDB table: {str(e)}")
        if xray_recorder.current_subsegment():
            xray_recorder.current_subsegment().add_exception(e)

        return {
            "statusCode": 500,
            "body": json.dumps(f"Error scanning DynamoDB table: {str(e)}")
        }
